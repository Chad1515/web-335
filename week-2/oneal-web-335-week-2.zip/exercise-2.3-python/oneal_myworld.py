"""
    Title: Exercise 2.3 myworld.py
    Author: Chad ONeal
    Date: 10/27/22
    Description: Exercise 2.3
"""

myName = "Chad ONeal's"
print("You are now in " + myName + "'s world!")